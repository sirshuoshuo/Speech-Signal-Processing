% 第一个信号应该在7000处开始，s5.wav

STSA_SingleFrame("s5.wav", 7000, 40);

% 第二个信号从10000开始，vowel_iy_100hz.wav

STSA_SingleFrame("vowel_iy_100hz.wav", 1000, 40);

